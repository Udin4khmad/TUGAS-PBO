package akhmad.zainudin;


public class luas_segitiga_zainudin {
    public static void main(String[] args) {
        int a = 35;
        int t = 35;
        double Luas = 0.5 * a * t;
        
        System.out.println ("alas = " + (a));
        System.out.println ("tinggi = " + (t));
        System.out.println ("Luas Segitiga = " + (Luas));
    }
}
