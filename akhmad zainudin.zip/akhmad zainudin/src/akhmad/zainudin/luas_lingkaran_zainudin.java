package akhmad.zainudin;


public class luas_lingkaran_zainudin {
     public static void main(String[] args) {
        int phi = 22/7;
        int r = 35;
        double Luas = phi * r * r;
        
        System.out.println ("jari jari = " + (r));
        System.out.println ("Luas Lingkaran = " + (Luas));
    }
}
